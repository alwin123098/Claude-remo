import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { SceneIntro } from "./scenes/SceneIntro";
import { SceneMeet } from "./scenes/SceneMeet";
import { SceneFeatures } from "./scenes/SceneFeatures";
import { SceneChat } from "./scenes/SceneChat";
import { SceneCTA } from "./scenes/SceneCTA";
import { Voiceover } from "./scenes/SceneVoiceover";
import { FadeTransition } from "./scenes/SceneTransition";

// Total: 900 frames = 30 seconds at 30fps
// Scene timing:
// 0-180   : Intro (6s)
// 180-360 : Meet Claude (6s)
// 360-540 : Features (6s)
// 540-720 : Chat demo (6s)
// 720-900 : CTA (6s)

const INTRO_START = 0;
const MEET_START = 180;
const FEAT_START = 360;
const CHAT_START = 540;
const CTA_START = 720;
const TOTAL = 900;

export const ClaudeAd: React.FC = () => {
  return (
    <AbsoluteFill style={{ backgroundColor: "#000000", fontFamily: "'Georgia', serif" }}>

      {/* ── SCENE 1: INTRO ── */}
      <Sequence from={INTRO_START} durationInFrames={MEET_START - INTRO_START + 20}>
        <SceneIntro />
      </Sequence>

      {/* ── SCENE 2: MEET ── */}
      <Sequence from={MEET_START} durationInFrames={FEAT_START - MEET_START + 20}>
        <SceneMeet />
      </Sequence>

      {/* ── SCENE 3: FEATURES ── */}
      <Sequence from={FEAT_START} durationInFrames={CHAT_START - FEAT_START + 20}>
        <SceneFeatures />
      </Sequence>

      {/* ── SCENE 4: CHAT ── */}
      <Sequence from={CHAT_START} durationInFrames={CTA_START - CHAT_START + 20}>
        <SceneChat />
      </Sequence>

      {/* ── SCENE 5: CTA ── */}
      <Sequence from={CTA_START} durationInFrames={TOTAL - CTA_START}>
        <SceneCTA />
      </Sequence>

      {/* ── VOICEOVER CAPTIONS ── */}
      <Sequence from={INTRO_START + 60} durationInFrames={90}>
        <Voiceover text="In a world full of noise, one voice stands out." />
      </Sequence>
      <Sequence from={MEET_START + 20} durationInFrames={120}>
        <Voiceover text="Meet Claude — an AI designed to think, understand, and truly help." />
      </Sequence>
      <Sequence from={FEAT_START + 30} durationInFrames={130}>
        <Voiceover text="Whether you're writing, researching, coding, or creating — Claude is ready." />
      </Sequence>
      <Sequence from={CHAT_START + 20} durationInFrames={130}>
        <Voiceover text="Have real conversations. Get real answers. Feel genuinely understood." />
      </Sequence>
      <Sequence from={CTA_START + 30} durationInFrames={130}>
        <Voiceover text="Claude. The AI that thinks, creates, and cares. Try it free today." />
      </Sequence>

      {/* ── FADE TRANSITIONS ── */}
      {/* Fade in at start */}
      <Sequence from={INTRO_START} durationInFrames={20}>
        <FadeTransition direction="in" durationFrames={20} />
      </Sequence>

      {/* Crossfade 1→2 */}
      <Sequence from={MEET_START - 10} durationInFrames={20}>
        <FadeTransition direction="out" durationFrames={10} />
      </Sequence>
      <Sequence from={MEET_START} durationInFrames={15}>
        <FadeTransition direction="in" durationFrames={15} />
      </Sequence>

      {/* Crossfade 2→3 */}
      <Sequence from={FEAT_START - 10} durationInFrames={20}>
        <FadeTransition direction="out" durationFrames={10} />
      </Sequence>
      <Sequence from={FEAT_START} durationInFrames={15}>
        <FadeTransition direction="in" durationFrames={15} />
      </Sequence>

      {/* Crossfade 3→4 */}
      <Sequence from={CHAT_START - 10} durationInFrames={20}>
        <FadeTransition direction="out" durationFrames={10} />
      </Sequence>
      <Sequence from={CHAT_START} durationInFrames={15}>
        <FadeTransition direction="in" durationFrames={15} />
      </Sequence>

      {/* Crossfade 4→5 */}
      <Sequence from={CTA_START - 10} durationInFrames={20}>
        <FadeTransition direction="out" durationFrames={10} />
      </Sequence>
      <Sequence from={CTA_START} durationInFrames={15}>
        <FadeTransition direction="in" durationFrames={15} />
      </Sequence>

      {/* Fade out at end */}
      <Sequence from={TOTAL - 30} durationInFrames={30}>
        <FadeTransition direction="out" durationFrames={30} />
      </Sequence>
    </AbsoluteFill>
  );
};
