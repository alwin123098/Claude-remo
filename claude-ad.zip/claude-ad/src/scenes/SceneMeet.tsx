import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  spring,
} from "remotion";
import { Particles } from "../Particles";

export const SceneMeet: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const eyeScale = spring({ frame: frame - 5, fps, config: { damping: 60, stiffness: 100 } });
  const titleOpacity = interpolate(frame, [20, 45], [0, 1], { extrapolateRight: "clamp" });
  const titleY = interpolate(frame, [20, 45], [50, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const subtitleOpacity = interpolate(frame, [40, 60], [0, 1], { extrapolateRight: "clamp" });
  const ring1Scale = 1 + Math.sin(frame * 0.05) * 0.05;
  const ring2Scale = 1 + Math.sin(frame * 0.05 + 1) * 0.07;

  // Voiceover text
  const voiceOpacity = interpolate(frame, [30, 50], [0, 1], { extrapolateRight: "clamp" });

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(ellipse at 40% 50%, #1a0e0a 0%, #0a0604 100%)",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <Particles />

      {/* Animated rings */}
      <div style={{ position: "absolute", display: "flex", justifyContent: "center", alignItems: "center" }}>
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              width: 200 + i * 80,
              height: 200 + i * 80,
              borderRadius: "50%",
              border: `1px solid rgba(204,120,92,${0.3 / i})`,
              transform: `scale(${i === 1 ? ring1Scale : ring2Scale})`,
            }}
          />
        ))}
      </div>

      {/* Eye / orb */}
      <div
        style={{
          width: 160,
          height: 160,
          borderRadius: "50%",
          background: "radial-gradient(circle at 40% 35%, #E8B89A, #CC785C 50%, #5C2A0A)",
          transform: `scale(${eyeScale})`,
          boxShadow: "0 0 80px rgba(204,120,92,0.7), inset 0 0 40px rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: 50,
        }}
      >
        {/* Pupil */}
        <div
          style={{
            width: 50,
            height: 50,
            borderRadius: "50%",
            background: "radial-gradient(circle at 35% 30%, #4a2010, #1a0a05)",
            boxShadow: "0 0 20px rgba(0,0,0,0.8)",
          }}
        />
        {/* Highlight */}
        <div
          style={{
            position: "absolute",
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: "rgba(255,255,255,0.6)",
            top: 30,
            left: 42,
          }}
        />
      </div>

      <div style={{ transform: `translateY(${titleY}px)`, opacity: titleOpacity, textAlign: "center" }}>
        <div
          style={{
            fontSize: 72,
            fontFamily: "'Georgia', serif",
            color: "#FFFFFF",
            fontWeight: 700,
            letterSpacing: 4,
          }}
        >
          Meet Claude
        </div>
      </div>

      <div style={{ opacity: subtitleOpacity, textAlign: "center", marginTop: 20 }}>
        <div
          style={{
            fontSize: 30,
            fontFamily: "'Georgia', serif",
            color: "rgba(232,184,154,0.85)",
            fontWeight: 300,
            letterSpacing: 3,
          }}
        >
          Your intelligent AI companion
        </div>
      </div>

      {/* Voiceover caption */}
      <div
        style={{
          position: "absolute",
          bottom: 80,
          left: "50%",
          transform: "translateX(-50%)",
          opacity: voiceOpacity,
          textAlign: "center",
          maxWidth: 900,
        }}
      >
        <div
          style={{
            fontSize: 24,
            fontFamily: "'Georgia', serif",
            color: "rgba(255,255,255,0.5)",
            fontStyle: "italic",
            letterSpacing: 1,
          }}
        >
          "Imagine having an AI that thinks alongside you..."
        </div>
      </div>
    </AbsoluteFill>
  );
};
