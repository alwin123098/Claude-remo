import React from "react";
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  spring,
} from "remotion";
import { Particles } from "../Particles";

export const SceneIntro: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const bgOpacity = interpolate(frame, [0, 20], [0, 1], { extrapolateRight: "clamp" });
  const circleScale = spring({ frame: frame - 10, fps, config: { damping: 80, stiffness: 120 } });
  const circleOpacity = interpolate(frame, [10, 30], [0, 1], { extrapolateRight: "clamp" });
  const textY = interpolate(frame, [40, 70], [60, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const textOpacity = interpolate(frame, [40, 65], [0, 1], { extrapolateRight: "clamp" });
  const tagY = interpolate(frame, [60, 85], [40, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const tagOpacity = interpolate(frame, [60, 80], [0, 1], { extrapolateRight: "clamp" });
  const lineWidth = interpolate(frame, [75, 105], [0, 320], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const glowSize = 80 + Math.sin(frame * 0.08) * 20;

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(ellipse at 50% 50%, #1a0e0a 0%, #0d0705 60%, #000000 100%)",
        opacity: bgOpacity,
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <Particles />
      <div
        style={{
          position: "absolute",
          width: glowSize * 3,
          height: glowSize * 3,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(204,120,92,0.15) 0%, transparent 70%)",
          transform: `scale(${circleScale})`,
        }}
      />
      <div
        style={{
          width: 160,
          height: 160,
          borderRadius: "50%",
          background: "linear-gradient(135deg, #CC785C 0%, #8B4513 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transform: `scale(${circleScale})`,
          opacity: circleOpacity,
          boxShadow: "0 0 60px rgba(204,120,92,0.6), 0 0 120px rgba(204,120,92,0.3)",
          marginBottom: 40,
        }}
      >
        <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
          <path d="M40 10 L65 65 H55 L40 30 L25 65 H15 Z" fill="white" fillOpacity="0.95" />
          <path d="M28 50 H52" stroke="white" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
        </svg>
      </div>
      <div style={{ transform: `translateY(${textY}px)`, opacity: textOpacity, textAlign: "center" }}>
        <div
          style={{
            fontSize: 110,
            fontFamily: "'Georgia', serif",
            fontWeight: 700,
            color: "#FFFFFF",
            letterSpacing: 24,
            textTransform: "uppercase",
            textShadow: "0 0 40px rgba(204,120,92,0.5)",
          }}
        >
          CLAUDE
        </div>
      </div>
      <div
        style={{
          width: lineWidth,
          height: 3,
          background: "linear-gradient(90deg, #CC785C, #E8B89A)",
          borderRadius: 2,
          marginTop: 8,
          marginBottom: 20,
          boxShadow: "0 0 12px rgba(204,120,92,0.8)",
        }}
      />
      <div style={{ transform: `translateY(${tagY}px)`, opacity: tagOpacity, textAlign: "center" }}>
        <div
          style={{
            fontSize: 28,
            fontFamily: "'Georgia', serif",
            fontWeight: 300,
            color: "rgba(255,255,255,0.65)",
            letterSpacing: 8,
            textTransform: "uppercase",
          }}
        >
          by Anthropic
        </div>
      </div>
    </AbsoluteFill>
  );
};
