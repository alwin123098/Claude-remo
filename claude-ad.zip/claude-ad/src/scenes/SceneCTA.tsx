import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { Particles } from "../Particles";

export const SceneCTA: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const logoScale = spring({ frame: frame - 10, fps, config: { damping: 70, stiffness: 100 } });
  const titleOpacity = interpolate(frame, [25, 50], [0, 1], { extrapolateRight: "clamp" });
  const titleY = interpolate(frame, [25, 50], [40, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const btnScale = spring({ frame: frame - 55, fps, config: { damping: 60, stiffness: 90 } });
  const btnOpacity = interpolate(frame, [55, 75], [0, 1], { extrapolateRight: "clamp" });
  const urlOpacity = interpolate(frame, [75, 95], [0, 1], { extrapolateRight: "clamp" });
  const glowPulse = 0.5 + Math.sin(frame * 0.1) * 0.2;

  return (
    <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 50%, #1a0e0a 0%, #080402 100%)", justifyContent: "center", alignItems: "center", flexDirection: "column" }}>
      <Particles />

      {/* Background glow */}
      <div style={{ position: "absolute", width: 600, height: 600, borderRadius: "50%", background: `radial-gradient(circle, rgba(204,120,92,${glowPulse * 0.2}) 0%, transparent 70%)` }} />

      {/* Logo */}
      <div style={{ transform: `scale(${logoScale})`, marginBottom: 44, display: "flex", alignItems: "center", gap: 24 }}>
        <div style={{ width: 100, height: 100, borderRadius: "50%", background: "linear-gradient(135deg, #CC785C, #8B4513)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 0 50px rgba(204,120,92,0.6)" }}>
          <svg width="50" height="50" viewBox="0 0 80 80" fill="none">
            <path d="M40 10 L65 65 H55 L40 30 L25 65 H15 Z" fill="white" fillOpacity="0.95" />
            <path d="M28 50 H52" stroke="white" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
          </svg>
        </div>
        <div style={{ fontSize: 72, fontFamily: "'Georgia', serif", fontWeight: 700, color: "#FFFFFF", letterSpacing: 16, textShadow: "0 0 30px rgba(204,120,92,0.5)" }}>
          CLAUDE
        </div>
      </div>

      {/* Main CTA */}
      <div style={{ opacity: titleOpacity, transform: `translateY(${titleY}px)`, textAlign: "center", marginBottom: 48 }}>
        <div style={{ fontSize: 52, fontFamily: "'Georgia', serif", color: "#FFFFFF", fontWeight: 700, lineHeight: 1.3, maxWidth: 900, textAlign: "center" }}>
          The AI that thinks,<br />
          <span style={{ color: "#CC785C" }}>creates,</span> and cares.
        </div>
      </div>

      {/* Button */}
      <div style={{ transform: `scale(${btnScale})`, opacity: btnOpacity }}>
        <div style={{
          background: "linear-gradient(135deg, #CC785C 0%, #A0522D 100%)",
          borderRadius: 60,
          padding: "22px 70px",
          boxShadow: "0 0 40px rgba(204,120,92,0.5), 0 8px 30px rgba(0,0,0,0.4)",
          cursor: "pointer",
        }}>
          <div style={{ fontSize: 28, fontFamily: "'Georgia', serif", color: "#FFFFFF", fontWeight: 700, letterSpacing: 3 }}>
            Try Claude Free
          </div>
        </div>
      </div>

      {/* URL */}
      <div style={{ opacity: urlOpacity, marginTop: 36, textAlign: "center" }}>
        <div style={{ fontSize: 22, fontFamily: "'Georgia', serif", color: "rgba(232,184,154,0.7)", letterSpacing: 4 }}>
          claude.ai
        </div>
      </div>

      {/* Bottom tagline */}
      <div style={{ position: "absolute", bottom: 60, opacity: urlOpacity, textAlign: "center" }}>
        <div style={{ fontSize: 18, fontFamily: "'Georgia', serif", color: "rgba(255,255,255,0.3)", letterSpacing: 3, textTransform: "uppercase" }}>
          Powered by Anthropic · Built for Everyone
        </div>
      </div>
    </AbsoluteFill>
  );
};
