import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig, interpolate, spring } from "remotion";
import { Particles } from "../Particles";

const features = [
  { icon: "💡", title: "Smart Thinking", desc: "Solves complex problems with clarity" },
  { icon: "✍️", title: "Creative Writing", desc: "Stories, essays, code — anything" },
  { icon: "🔍", title: "Deep Research", desc: "Analyzes and summarizes instantly" },
  { icon: "🛡️", title: "Safe & Trusted", desc: "Built with safety at the core" },
];

export const SceneFeatures: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const titleOpacity = interpolate(frame, [0, 25], [0, 1], { extrapolateRight: "clamp" });
  const titleY = interpolate(frame, [0, 25], [-40, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

  return (
    <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 30%, #180c08 0%, #080402 100%)", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
      <Particles />
      <div style={{ opacity: titleOpacity, transform: `translateY(${titleY}px)`, marginBottom: 60, textAlign: "center" }}>
        <div style={{ fontSize: 52, fontFamily: "'Georgia', serif", color: "#CC785C", letterSpacing: 6, textTransform: "uppercase" }}>
          What Claude Can Do
        </div>
      </div>
      <div style={{ display: "flex", gap: 40, justifyContent: "center", flexWrap: "wrap", maxWidth: 1600, padding: "0 80px" }}>
        {features.map((f, i) => {
          const cardSpring = spring({ frame: frame - 20 - i * 12, fps, config: { damping: 70, stiffness: 100 } });
          const cardOpacity = interpolate(frame, [20 + i * 12, 40 + i * 12], [0, 1], { extrapolateRight: "clamp" });
          return (
            <div
              key={i}
              style={{
                width: 340,
                background: "linear-gradient(135deg, rgba(204,120,92,0.12), rgba(204,120,92,0.04))",
                border: "1px solid rgba(204,120,92,0.3)",
                borderRadius: 24,
                padding: "48px 40px",
                textAlign: "center",
                transform: `scale(${cardSpring}) translateY(${interpolate(cardSpring, [0, 1], [40, 0])}px)`,
                opacity: cardOpacity,
                boxShadow: "0 8px 40px rgba(204,120,92,0.1)",
              }}
            >
              <div style={{ fontSize: 60, marginBottom: 20 }}>{f.icon}</div>
              <div style={{ fontSize: 26, fontFamily: "'Georgia', serif", color: "#E8B89A", fontWeight: 700, marginBottom: 14 }}>{f.title}</div>
              <div style={{ fontSize: 18, fontFamily: "'Georgia', serif", color: "rgba(255,255,255,0.55)", lineHeight: 1.5 }}>{f.desc}</div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
